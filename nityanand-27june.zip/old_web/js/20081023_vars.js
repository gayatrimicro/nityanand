<!-- SiteCatalyst code version: H.17.Copyright 1997-2008 Omniture, Inc. More info available at http://www.omniture.com -->

/* Media Vars 20081023 V1 */

/* TRAFFIC VARIABLES */
s.pageName="";
s.server="";
s.channel="";
s.pageType="";
s.prop1="";
s.prop2="";
s.prop3="";
s.prop4="";
s.prop5="";
s.prop6="";
s.prop7="";
s.hier1="";

/* CONVERSION VARIABLES */
s.campaign="";
s.state="";
s.zip="";
s.events="";
s.products="";
s.purchaseID="";
s.eVar1="";
s.eVar2="";
s.eVar3="";
s.eVar4="";
s.eVar5="";

/************* DO NOT ALTER ANYTHING BELOW THIS LINE ! **************/

var s_code=s.t();if(s_code)document.write(s_code);
if(navigator.appVersion.indexOf('MSIE')>=0)document.write(unescape('%3C')+'\!-'+'-')
