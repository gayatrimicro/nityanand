<?php
$pgdomain="pg.eazy2pay.com";
$pgInstanceId="61382171";
$merchantId="32894653";
$hashKey="965996C0188DBD9E";

header("pragma".": "."no-cache");
header("cache-control".": "."No-cache");
?>
